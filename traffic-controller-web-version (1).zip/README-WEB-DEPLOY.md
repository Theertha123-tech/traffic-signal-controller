# Traffic & Emergency Signal Controller — Web Version

This is a browser-based adaptation of the uploaded Java Swing project. It represents the same main features:
- Four lanes: North, East, South, West
- Normal vehicle queues
- Emergency priority queue: Ambulance, Fire Engine, Police Vehicle
- Traffic density: Low, Medium, High
- Next Signal, Pass Vehicle, and Reset Queues controls
- Status and activity log

## Publish with GitHub Pages
1. Open https://github.com/Theertha123-tech/traffic-signal-controller
2. Click **Add file → Upload files**.
3. Upload `index.html`, `style.css`, and `script.js` into the repository root.
4. Click **Commit changes**.
5. Go to **Settings → Pages**.
6. Under Build and deployment choose **Deploy from a branch**.
7. Choose branch `main` and folder `/(root)`, then Save.
8. Wait for GitHub Pages to publish. The expected URL is:
   https://theertha123-tech.github.io/traffic-signal-controller/

This is a web adaptation of the Java Swing app, not the original Java source running inside the browser. Keep your `.java` file in the repository.
